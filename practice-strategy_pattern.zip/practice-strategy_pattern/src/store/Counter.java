package store;

import java.util.List;

public interface Counter<T> {
    public int countProduct(List<T> list);
}

// ไชยภัทร ศรีอำไพ 6510450305
