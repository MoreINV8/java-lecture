package Mail;

public interface Encryptor {
    public String encrypt(String content);
}

// ไชยภัทร ศรีอำไพ 6510450305
