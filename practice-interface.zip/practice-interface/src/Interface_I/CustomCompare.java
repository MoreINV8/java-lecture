package Interface_I;

public interface CustomCompare {
    public double getDataToCompare();
}

// ไชยภัทร ศรีอำไพ 6510450305