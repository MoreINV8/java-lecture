package Interface_II;

public class Product {
    private String name;
    private double price;

    // ขออนุญาติเพิ่ม constructor
    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }
    public double getPrice() {
        return price;
    }
}

// ไชยภัทร ศรีอำไพ 6510450305
