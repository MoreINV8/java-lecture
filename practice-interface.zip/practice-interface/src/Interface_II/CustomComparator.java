package Interface_II;

public interface CustomComparator<T> {
    public int compareData(T obj1, T obj2);
    public double getData(T obj);
}

// ไชยภัทร ศรีอำไพ 6510450305
